from django.apps import AppConfig


class PhotoConfig(AppConfig):
    name = 'photo'
